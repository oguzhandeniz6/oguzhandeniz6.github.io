#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
import matplotlib.pyplot as plt

# Load the data
# Change 'output_scut.csv' for SCUT dataset, 'output_mebeauty.csv' for MeBeauty dataset
data = pd.read_csv("/home/oguzhan/Desktop/output_mebeauty.csv")

# Extract gender from 'names' column and create separate DataFrames
# Change 'F' for SCUT dataset, 'female' for MeBeauty dataset
data['gender'] = data['names'].apply(lambda x: 'Female' if 'female' in x else 'Male')
female_data = data[data['gender'] == 'Female']
male_data = data[data['gender'] == 'Male']

# Function to prepare and scale the data
def prepare_data(df):
    df = df.drop(columns=["names", "gender"], axis=1)
    df['att_level'] = df['att_level'].round().astype(int)
    cols_to_scale = df.columns[:-1]
    X, y = df.drop(columns=['att_level']).to_numpy(), df["att_level"].to_numpy()
    standard_scaler = StandardScaler()
    X_scaled = standard_scaler.fit_transform(df.drop(columns=['att_level']))
    return X, y, X_scaled

# Prepare data for females and males
X_female, y_female, X_scaled_female = prepare_data(female_data)
X_male, y_male, X_scaled_male = prepare_data(male_data)

# Define the classification models to be tested
classifiers = {
    'Decision Tree': DecisionTreeClassifier(random_state=42),
    'Random Forest': RandomForestClassifier(random_state=42),
    'Support Vector Classifier': SVC(random_state=42),
    'K-Nearest Neighbors': KNeighborsClassifier()
}

# Function to evaluate classification models
def evaluate_classification_model(X, y, model):
    kfold = KFold(n_splits=5, shuffle=True, random_state=42)
    accuracy_scores, precision_scores, recall_scores, f1_scores = [], [], [], []

    for train_index, test_index in kfold.split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        accuracy_scores.append(accuracy_score(y_test, y_pred))
        precision_scores.append(precision_score(y_test, y_pred, average='weighted', zero_division=0))
        recall_scores.append(recall_score(y_test, y_pred, average='weighted', zero_division=0))
        f1_scores.append(f1_score(y_test, y_pred, average='weighted', zero_division=0))

    return {
        'Accuracy': np.mean(accuracy_scores),
        'Precision': np.mean(precision_scores),
        'Recall': np.mean(recall_scores),
        'F1 Score': np.mean(f1_scores)
    }

# Evaluate all models on both normalized and non-normalized data for females and males
classification_results_female = {}
classification_results_male = {}

for name, model in classifiers.items():
    print(f"Evaluating {name} for females without normalization")
    classification_results_female[f"{name} (non-normalized)"] = evaluate_classification_model(X_female, y_female, model)

    print(f"Evaluating {name} for females with normalization")
    classification_results_female[f"{name} (normalized)"] = evaluate_classification_model(X_scaled_female, y_female, model)

    print(f"Evaluating {name} for males without normalization")
    classification_results_male[f"{name} (non-normalized)"] = evaluate_classification_model(X_male, y_male, model)

    print(f"Evaluating {name} for males with normalization")
    classification_results_male[f"{name} (normalized)"] = evaluate_classification_model(X_scaled_male, y_male, model)

# Function to plot metrics
def plot_classification_metrics(results, title):
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1 Score']
    model_names = list(results.keys())
    n_metrics = len(metrics)
    
    fig, axs = plt.subplots(n_metrics, 1, figsize=(10, 20))
    
    for i, metric in enumerate(metrics):
        values = [results[model][metric] for model in model_names]
        axs[i].barh(model_names, values, color='skyblue')
        axs[i].set_title(f"{metric} - {title}")
        axs[i].set_xlabel(metric)
        axs[i].set_ylabel('Models')
    
    plt.tight_layout()
    plt.show()

# Plot results for females and males
plot_classification_metrics(classification_results_female, "Females")
plot_classification_metrics(classification_results_male, "Males")
