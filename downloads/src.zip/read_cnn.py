#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import csv

# Variables
new_base_dir = "/home/oguzhan/Desktop/MEBeauty-database-main/original_images"

# Files to process
file_list = [
    "/home/oguzhan/Desktop/MEBeauty-database-main/scores/train.txt",
    "/home/oguzhan/Desktop/MEBeauty-database-main/scores/val.txt",
    "/home/oguzhan/Desktop/MEBeauty-database-main/scores/test.txt"
]

def read_labels(files):
    labels_dict = {}
    for filename in files:
        with open(filename, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) >= 2:
                    # Update the image path
                    old_path = parts[0]
                    relative_path = old_path.split("/", 4)[-1]  # Get the path after the 4th '/'
                    new_path = os.path.join(new_base_dir, relative_path)
                    label = parts[1]
                    labels_dict[new_path] = label
    return labels_dict

def create_csv(data, filename):
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=['image_path', 'label'])
        writer.writeheader()
        for path, label in data.items():
            writer.writerow({'image_path': path, 'label': label})

# Read labels and image paths
image_label_dict = read_labels(file_list)

# Write data to CSV file
create_csv(image_label_dict, 'output_cnn.csv')
