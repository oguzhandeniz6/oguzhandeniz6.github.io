#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import csv
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# Variables
model_path = "/home/oguzhan/Desktop/face_landmarker_v2_with_blendshapes.task"

# Define new base directory
new_base_dir = "/home/oguzhan/Desktop/MEBeauty-database-main/original_images"

# Files to process
file_list = ["/home/oguzhan/Desktop/MEBeauty-database-main/scores/train.txt", 
             "/home/oguzhan/Desktop/MEBeauty-database-main/scores/val.txt", 
             "/home/oguzhan/Desktop/MEBeauty-database-main/scores/test.txt"]

def read_labels(files):
    labels_dict = {}
    for filename in files:
        with open(filename, 'r') as file:
            for line in file:
                parts = line.strip().split()
                if len(parts) >= 2:
                    # Update the image path
                    old_path = parts[0]
                    relative_path = old_path.split("/", 4)[-1]  # Get the path after the 4th '/'
                    new_path = os.path.join(new_base_dir, relative_path)
                    label = parts[1]
                    labels_dict[new_path] = label
    return labels_dict

# Create a dictionary containing facial landmark names and corresponding scores
def create_facial_landmark_dict(path, face_blendshapes, label):
    face_blendshapes_names = [face_blendshapes_category.category_name 
                              for face_blendshapes_category in face_blendshapes]
    face_blendshapes_scores = [face_blendshapes_category.score for 
                               face_blendshapes_category in face_blendshapes]
    
    face_blendshapes_names.insert(0, "names")
    face_blendshapes_scores.insert(0, path)
    face_blendshapes_names.append("att_level")
    face_blendshapes_scores.append(label)
    
    return dict(zip(face_blendshapes_names, face_blendshapes_scores))

# Write obtained facial landmark dictionaries to a CSV file
def create_csv(data, filename):
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=data[0].keys())
        writer.writeheader()
        for row in data:
            writer.writerow(row)

# Read labels and image paths
image_label_dict = read_labels(file_list)

# Define option model for MediaPipe
base_options = python.BaseOptions(model_asset_path=model_path)

options = vision.FaceLandmarkerOptions(base_options=base_options,
                                       output_face_blendshapes=True,
                                       output_facial_transformation_matrixes=True,
                                       num_faces=1)

# Create a Face Landmark Detector object
detector = vision.FaceLandmarker.create_from_options(options)

facial_landmark_data = []

# Detect facial landmarks for each image
for path, label in image_label_dict.items():
    if os.path.exists(path):
        try:
            img = mp.Image.create_from_file(path)
            detection_result = detector.detect(img)
            if detection_result.face_blendshapes:
                facial_landmark_data.append(create_facial_landmark_dict(path, detection_result.face_blendshapes[0], label))
        except Exception as e:
            print(f"Error processing {path}: {e}")

# Write data to CSV files
create_csv(facial_landmark_data, 'output_mebeauty.csv')
