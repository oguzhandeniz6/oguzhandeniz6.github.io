#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
from sklearn.neighbors import KNeighborsRegressor
import matplotlib.pyplot as plt

# Load the data
# Change 'output_scut.csv' for SCUT dataset, 'output_mebeauty.csv' for MeBeauty dataset
data = pd.read_csv("/home/oguzhan/Desktop/output_mebeauty.csv")

# Extract gender from 'names' column and create separate DataFrames
# Change 'F' for SCUT dataset, 'female' for MeBeauty dataset
data['gender'] = data['names'].apply(lambda x: 'Female' if 'female' in x else 'Male')
female_data = data[data['gender'] == 'Female']
male_data = data[data['gender'] == 'Male']

# Function to prepare and scale the data
def prepare_data(df):
    df = df.drop(columns=["names", "gender"], axis=1)
    cols_to_scale = df.columns[:-1]
    X, y = df.drop(columns=['att_level']).to_numpy(), df["att_level"].to_numpy()
    standard_scaler = StandardScaler()
    X_scaled = standard_scaler.fit_transform(df.drop(columns=['att_level']))
    return X, y, X_scaled

# Prepare data for females and males
X_female, y_female, X_scaled_female = prepare_data(female_data)
X_male, y_male, X_scaled_male = prepare_data(male_data)

# Define the regression models to be tested
regressors = {
    'Linear Regression': LinearRegression(),
    'Decision Tree': DecisionTreeRegressor(random_state=42),
    'Random Forest': RandomForestRegressor(random_state=42),
    'Support Vector Regression': SVR(),
    'K-Nearest Neighbors': KNeighborsRegressor()
}

# Function to evaluate models
def evaluate_model(X, y, model):
    kfold = KFold(n_splits=5, shuffle=True, random_state=42)
    mse_scores, mae_scores, rmse_scores, r2_scores = [], [], [], []

    for train_index, test_index in kfold.split(X):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        mse_scores.append(mean_squared_error(y_test, y_pred))
        mae_scores.append(mean_absolute_error(y_test, y_pred))
        rmse_scores.append(np.sqrt(mean_squared_error(y_test, y_pred)))
        r2_scores.append(r2_score(y_test, y_pred))

    return {
        'Mean MSE': np.mean(mse_scores),
        'Mean MAE': np.mean(mae_scores),
        'Mean RMSE': np.mean(rmse_scores),
        'Mean R-squared': np.mean(r2_scores)
    }

# Evaluate all models on both normalized and non-normalized data for females and males
results_female = {}
results_male = {}

for name, model in regressors.items():
    print(f"Evaluating {name} for females without normalization")
    results_female[f"{name} (non-normalized)"] = evaluate_model(X_female, y_female, model)

    print(f"Evaluating {name} for females with normalization")
    results_female[f"{name} (normalized)"] = evaluate_model(X_scaled_female, y_female, model)

    print(f"Evaluating {name} for males without normalization")
    results_male[f"{name} (non-normalized)"] = evaluate_model(X_male, y_male, model)

    print(f"Evaluating {name} for males with normalization")
    results_male[f"{name} (normalized)"] = evaluate_model(X_scaled_male, y_male, model)

# Function to plot metrics
def plot_metrics(results, title):
    metrics = ['Mean MSE', 'Mean MAE', 'Mean RMSE', 'Mean R-squared']
    model_names = list(results.keys())
    n_metrics = len(metrics)
    
    fig, axs = plt.subplots(n_metrics, 1, figsize=(10, 20))
    
    for i, metric in enumerate(metrics):
        values = [results[model][metric] for model in model_names]
        axs[i].barh(model_names, values, color='skyblue')
        axs[i].set_title(f"{metric} - {title}")
        axs[i].set_xlabel(metric)
        axs[i].set_ylabel('Models')
    
    plt.tight_layout()
    plt.show()

# Plot results for females and males
plot_metrics(results_female, "Females")
plot_metrics(results_male, "Males")
