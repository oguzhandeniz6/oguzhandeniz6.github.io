#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import csv
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

# Variables
images_directory = "Images"
labels_filename = "all_labels.txt"
model_path = "/home/oguzhan/Desktop/face_landmarker_v2_with_blendshapes.task"


# Read corresponding labels to images
def read_labels(filename):
    labels_dict = {}
    
    with open(filename, 'r') as file:
        for line in file:
            parts = line.strip().split()  # format is "image_name label"
            
            if len(parts) >= 2:
                image_name = parts[0]
                label = parts[1]
                labels_dict[image_name] = label
                
    return labels_dict


# Get image paths to use in image reading operations
def get_image_paths(directory):
    image_paths = {}
    
    for root, _, files in os.walk(directory):
        for file in files:
            
            if file.lower().endswith(('.png', '.jpg', '.jpeg')):
                image_paths[file] = os.path.join(root, file)
                
    return image_paths


# Create a dictionary contains image paths and corresponding labels
def create_image_label_dict(images_directory, labels_filename):
    image_paths = get_image_paths(images_directory)
    labels_dict = read_labels(labels_filename)
    image_label_dict = {}
    for image_name, label in labels_dict.items():
        if image_name in image_paths:
            image_label_dict[image_paths[image_name]] = label
    return image_label_dict


# Create a dictionary contains facial landmark names and corresponding scores
def create_facial_landmark_dict(path, face_blendshapes, label):
    # Extract names and scores 
    face_blendshapes_names = [face_blendshapes_category.category_name 
                              for face_blendshapes_category in face_blendshapes]
    face_blendshapes_scores = [face_blendshapes_category.score for 
                               face_blendshapes_category in face_blendshapes]
    
    # Add names column and corresponding image names(paths)
    face_blendshapes_names.insert(0, "names")
    face_blendshapes_scores.insert(0, path)
    # Add att. level column and corresponding image att. level(label)
    face_blendshapes_names.append("att_level")
    face_blendshapes_scores.append(label)
    
    # Stitch names and scores together in a dictionary
    return dict(zip(face_blendshapes_names, face_blendshapes_scores))


# Write obtained facial landmark dictionaries to .csv file
def create_csv(fl_data):
    # Write data to CSV file
    with open("output_scut.csv", 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fl_data[0].keys())
        
        # Write header row
        writer.writeheader()
        
        # Write data rows
        for row in fl_data:
            writer.writerow(row)


# Obtain an image label dictionary
image_label_dict = create_image_label_dict(images_directory, labels_filename)

# Define option model for mediapipe
base_options = python.BaseOptions(model_asset_path= model_path)

options = vision.FaceLandmarkerOptions(base_options=base_options,
                                       output_face_blendshapes=True,
                                       output_facial_transformation_matrixes=True,
                                       num_faces=1)

# Create a Face Landmark Detector object
detector = vision.FaceLandmarker.create_from_options(options)

facial_landmark_data = []

# Detect facial landmark of each image
for path, label in image_label_dict.items():
    
    # Read image with mediapipe's function
    img = mp.Image.create_from_file(path)
    
    # Detect facial landmarks
    detection_result = detector.detect(img)
    
    # Extract the face blendshapes category names and scores in one dictionary
    facial_landmark_data.append(create_facial_landmark_dict(path,
        detection_result.face_blendshapes[0], label))
    
    
# Write data to .csv file
create_csv(facial_landmark_data)




